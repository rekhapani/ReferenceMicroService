package com.reference.order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.reference.order.dto.OrderDTO;
import com.reference.order.kafka.producer.KafkaOrderSender;
import com.reference.order.kafka.producer.Order1DTO;




@SpringBootApplication(exclude = KafkaAutoConfiguration.class)
public class OrderMicroServiceApplication implements CommandLineRunner{// extends SpringBootServletInitializer{

	public static void main(String[] args) {
		SpringApplication.run(OrderMicroServiceApplication.class, args);
	}
	/*@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(OrderMicroServiceApplication.class);
	}*/
	@Autowired
    private KafkaOrderSender sender;
	@Override
    public void run(String... strings) throws Exception {
        Order1DTO dto = new Order1DTO();
     dto.setCommitmentID(1);
       dto.setNationalAccountID(2);
        dto.setBillToID(3);
        sender.send(dto);
    }

}
