package com.reference.order.kafka.producer;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

import lombok.Data;
@Data
public class Order1DTO {
		private Integer commitmentID;
		public Integer getCommitmentID() {
			return commitmentID;
		}
		public void setCommitmentID(Integer commitmentID) {
			this.commitmentID = commitmentID;
		}
		public Integer getNationalAccountID() {
			return nationalAccountID;
		}
		public void setNationalAccountID(Integer nationalAccountID) {
			this.nationalAccountID = nationalAccountID;
		}
		public Integer getBillToID() {
			return billToID;
		}
		public void setBillToID(Integer billToID) {
			this.billToID = billToID;
		}
		private Integer nationalAccountID;
		private Integer billToID;
		
		
		
		
		
}
